var classmega_1_1_synchronous_transfer_listener =
[
    [ "SynchronousTransferListener", "classmega_1_1_synchronous_transfer_listener.html#a270019b73ce7bb49aa6ff439a3ba6ed6", null ],
    [ "~SynchronousTransferListener", "classmega_1_1_synchronous_transfer_listener.html#a1eeff2b680ad9b87cca2ce40e1431065", null ],
    [ "doOnTransferFinish", "classmega_1_1_synchronous_transfer_listener.html#a2009fccd6edd73d0af61ec189b788fcb", null ],
    [ "getApi", "classmega_1_1_synchronous_transfer_listener.html#a0d0fbabd3cec9bf26071017386f773f2", null ],
    [ "getError", "classmega_1_1_synchronous_transfer_listener.html#a76ce46ba8aabad1a7a4a4ff4e9f1a1d1", null ],
    [ "getTransfer", "classmega_1_1_synchronous_transfer_listener.html#aa712fe6fade3fb5e6f6f8f2442b81111", null ],
    [ "trywait", "classmega_1_1_synchronous_transfer_listener.html#a262e8f6ad6f9c11663df66e8840c8c85", null ],
    [ "wait", "classmega_1_1_synchronous_transfer_listener.html#a82300fdb734e656f8f25ded25ebd3e34", null ],
    [ "listener", "classmega_1_1_synchronous_transfer_listener.html#aacd1a18acb331e8d0af2eecbb3cc1be2", null ],
    [ "megaApi", "classmega_1_1_synchronous_transfer_listener.html#ae682271c4689b2f0aadf8e5fff206e45", null ],
    [ "megaError", "classmega_1_1_synchronous_transfer_listener.html#afab54dd2a4cf9a5f2302a4ec2aabac34", null ],
    [ "megaTransfer", "classmega_1_1_synchronous_transfer_listener.html#a6c13b3c95f624a28f527e9b859dd4485", null ]
];