var classmega_1_1_mega_transfer_listener =
[
    [ "~MegaTransferListener", "classmega_1_1_mega_transfer_listener.html#a2cd6d4bce614a9e1d1d2342ef5b29bfc", null ],
    [ "onTransferData", "classmega_1_1_mega_transfer_listener.html#a6ed4b290ff7971d8379ea22b1261fc9c", null ],
    [ "onTransferFinish", "classmega_1_1_mega_transfer_listener.html#a9e3a33f49d9768a3517b569f8e6b51e3", null ],
    [ "onTransferStart", "classmega_1_1_mega_transfer_listener.html#a31d2f594aaa6c91e685ed51c06c88ffe", null ],
    [ "onTransferTemporaryError", "classmega_1_1_mega_transfer_listener.html#a061da7afca5c538020b6907de7e5d96d", null ],
    [ "onTransferUpdate", "classmega_1_1_mega_transfer_listener.html#afb0f289e925db0592cec2d0f95928004", null ]
];