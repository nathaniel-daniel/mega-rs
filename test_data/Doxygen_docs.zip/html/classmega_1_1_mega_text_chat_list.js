var classmega_1_1_mega_text_chat_list =
[
    [ "~MegaTextChatList", "classmega_1_1_mega_text_chat_list.html#aafecf999f5112a7df02cbac6efc7e80c", null ],
    [ "copy", "classmega_1_1_mega_text_chat_list.html#ab32c932776e9e52b35b69da02fa61200", null ],
    [ "get", "classmega_1_1_mega_text_chat_list.html#a9960432575c716b7f167a8f4973f71fc", null ],
    [ "size", "classmega_1_1_mega_text_chat_list.html#a1003a6296f9b435e52747d7a0ea72f92", null ]
];