var classmega_1_1_mega_request_listener =
[
    [ "~MegaRequestListener", "classmega_1_1_mega_request_listener.html#a0e0666e6d995e43c21e0f281e2bb2d66", null ],
    [ "onRequestFinish", "classmega_1_1_mega_request_listener.html#a01b7996ea7e147072332c4bfeca24635", null ],
    [ "onRequestStart", "classmega_1_1_mega_request_listener.html#a10452f65685a903eb4cf94adf7df28d6", null ],
    [ "onRequestTemporaryError", "classmega_1_1_mega_request_listener.html#aca7daed4efde05de3ae658a52d261592", null ],
    [ "onRequestUpdate", "classmega_1_1_mega_request_listener.html#abe1e521e868b0d60e4d5f6c858effc6c", null ]
];