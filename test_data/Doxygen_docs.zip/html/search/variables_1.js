var searchData=
[
  ['listener',['listener',['../classmega_1_1_synchronous_request_listener.html#a02cf865bc5fcb70e7ea89cb548874877',1,'mega::SynchronousRequestListener::listener()'],['../classmega_1_1_synchronous_transfer_listener.html#aacd1a18acb331e8d0af2eecbb3cc1be2',1,'mega::SynchronousTransferListener::listener()']]]
];
