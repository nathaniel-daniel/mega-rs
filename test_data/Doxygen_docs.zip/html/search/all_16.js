var searchData=
[
  ['wait',['wait',['../classmega_1_1_synchronous_request_listener.html#a6c61f495bb3138baa6f53fc272c12365',1,'mega::SynchronousRequestListener::wait()'],['../classmega_1_1_synchronous_transfer_listener.html#a82300fdb734e656f8f25ded25ebd3e34',1,'mega::SynchronousTransferListener::wait()']]]
];
