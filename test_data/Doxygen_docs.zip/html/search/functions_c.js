var searchData=
[
  ['megaapi',['MegaApi',['../classmega_1_1_mega_api.html#a077efc5e892f5688522df39bc32ccb74',1,'mega::MegaApi::MegaApi(const char *appKey, const char *basePath=NULL, const char *userAgent=NULL)'],['../classmega_1_1_mega_api.html#a779360f8f5023160f7bf5d81914aa233',1,'mega::MegaApi::MegaApi(const char *appKey, MegaGfxProcessor *processor, const char *basePath=NULL, const char *userAgent=NULL)'],['../classmega_1_1_mega_api.html#a0218eebaf07a7e7bc7a3959e364b2582',1,'mega::MegaApi::MegaApi(const char *appKey, const char *basePath, const char *userAgent, int fseventsfd)']]],
  ['megaerror',['MegaError',['../classmega_1_1_mega_error.html#a15593838d9f5e41c0e77722bc18977d5',1,'mega::MegaError::MegaError(int errorCode=MegaError::API_OK)'],['../classmega_1_1_mega_error.html#aa5bf2b5e796207f672ef5f95be7147f1',1,'mega::MegaError::MegaError(int errorCode, long long value)'],['../classmega_1_1_mega_error.html#aba5a8258c2b2ebba6becd0e5026416be',1,'mega::MegaError::MegaError(const MegaError &amp;megaError)']]],
  ['megahashsignature',['MegaHashSignature',['../classmega_1_1_mega_hash_signature.html#aaad2533799d5fbcad5d32623c17b6021',1,'mega::MegaHashSignature']]],
  ['megaproxy',['MegaProxy',['../classmega_1_1_mega_proxy.html#aace50c748cdbf154f35753435bbf1776',1,'mega::MegaProxy']]],
  ['megatextchatpeerlist',['MegaTextChatPeerList',['../classmega_1_1_mega_text_chat_peer_list.html#a544213e8e808148a4ce17f89c1e5f193',1,'mega::MegaTextChatPeerList']]],
  ['movenode',['moveNode',['../classmega_1_1_mega_api.html#a0f8edcbfd7aac284680baa7727741b6a',1,'mega::MegaApi']]],
  ['movetolocaldebris',['moveToLocalDebris',['../classmega_1_1_mega_api.html#aae83260809cdcea8f0ef015c750f8930',1,'mega::MegaApi']]],
  ['movetransferbefore',['moveTransferBefore',['../classmega_1_1_mega_api.html#ac584d21f8847691d867a8f840b5f3d73',1,'mega::MegaApi']]],
  ['movetransferbeforebytag',['moveTransferBeforeByTag',['../classmega_1_1_mega_api.html#a64fe53178707f86d864759178ff7756a',1,'mega::MegaApi']]],
  ['movetransferdown',['moveTransferDown',['../classmega_1_1_mega_api.html#a7959012fdb7505012eee6fa94777666b',1,'mega::MegaApi']]],
  ['movetransferdownbytag',['moveTransferDownByTag',['../classmega_1_1_mega_api.html#a7b89252810a4d1998231795902906b6e',1,'mega::MegaApi']]],
  ['movetransfertofirst',['moveTransferToFirst',['../classmega_1_1_mega_api.html#a3ed612d11083c7a7a9d7ec47c5dbcd2d',1,'mega::MegaApi']]],
  ['movetransfertofirstbytag',['moveTransferToFirstByTag',['../classmega_1_1_mega_api.html#a9a6731b7965e813d4de2658abb0b3c21',1,'mega::MegaApi']]],
  ['movetransfertolast',['moveTransferToLast',['../classmega_1_1_mega_api.html#ae057f819dd5d158157d30095618a379d',1,'mega::MegaApi']]],
  ['movetransfertolastbytag',['moveTransferToLastByTag',['../classmega_1_1_mega_api.html#acfe7ecc40f49b3ceac185322db3102c7',1,'mega::MegaApi']]],
  ['movetransferup',['moveTransferUp',['../classmega_1_1_mega_api.html#a348bff15ead68c2ecb75618fcb38699d',1,'mega::MegaApi']]],
  ['movetransferupbytag',['moveTransferUpByTag',['../classmega_1_1_mega_api.html#aaa0b18d1595c5b2c9b0f74cefd7fff95',1,'mega::MegaApi']]]
];
