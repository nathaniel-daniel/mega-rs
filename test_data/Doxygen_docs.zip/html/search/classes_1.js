var searchData=
[
  ['synchronousrequestlistener',['SynchronousRequestListener',['../classmega_1_1_synchronous_request_listener.html',1,'mega']]],
  ['synchronoustransferlistener',['SynchronousTransferListener',['../classmega_1_1_synchronous_transfer_listener.html',1,'mega']]]
];
