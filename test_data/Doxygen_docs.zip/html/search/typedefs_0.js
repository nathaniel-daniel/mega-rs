var searchData=
[
  ['megahandle',['MegaHandle',['../namespacemega.html#a7a49aa59fd3826b739c068eaaee7c58f',1,'mega']]]
];
