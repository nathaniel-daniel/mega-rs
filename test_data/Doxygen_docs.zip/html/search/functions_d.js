var searchData=
[
  ['notifytransfer',['notifyTransfer',['../classmega_1_1_mega_api.html#a180735582903fa75456f8ffffd54fe6e',1,'mega::MegaApi']]],
  ['notifytransferbytag',['notifyTransferByTag',['../classmega_1_1_mega_api.html#ae56ef743d7112806c97aeb6955e88390',1,'mega::MegaApi']]]
];
