var searchData=
[
  ['move_5ftype_5fbottom',['MOVE_TYPE_BOTTOM',['../classmega_1_1_mega_transfer.html#aa49112da17f356402d820ee1c4caaf74a4fab6d9621e52196fae9a0927f4b1e30',1,'mega::MegaTransfer']]],
  ['move_5ftype_5fdown',['MOVE_TYPE_DOWN',['../classmega_1_1_mega_transfer.html#aa49112da17f356402d820ee1c4caaf74a1881451b35a4f5d04df108ef72ba365a',1,'mega::MegaTransfer']]],
  ['move_5ftype_5ftop',['MOVE_TYPE_TOP',['../classmega_1_1_mega_transfer.html#aa49112da17f356402d820ee1c4caaf74a1d6b1432528ce9af87466b03d6333268',1,'mega::MegaTransfer']]],
  ['move_5ftype_5fup',['MOVE_TYPE_UP',['../classmega_1_1_mega_transfer.html#aa49112da17f356402d820ee1c4caaf74ae83f0256f11d96a30545e040c9e942fa',1,'mega::MegaTransfer']]]
];
