var searchData=
[
  ['node_5fattr_5fcoordinates',['NODE_ATTR_COORDINATES',['../classmega_1_1_mega_api.html#a911d284175c27141dc613586187f757da8b64b4ed3f5816e3408b8dfefaa7888c',1,'mega::MegaApi']]],
  ['node_5fattr_5fduration',['NODE_ATTR_DURATION',['../classmega_1_1_mega_api.html#a911d284175c27141dc613586187f757da19f390673b28452070c7b94e8040991f',1,'mega::MegaApi']]]
];
