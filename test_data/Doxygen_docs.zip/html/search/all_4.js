var searchData=
[
  ['deprecated_20list',['Deprecated List',['../deprecated.html',1,'']]],
  ['disableexport',['disableExport',['../classmega_1_1_mega_api.html#ab3439625b567249a9fe18015d8a7a9df',1,'mega::MegaApi']]],
  ['disablesync',['disableSync',['../classmega_1_1_mega_api.html#a870ad3e6ee1b4bc73661b039646468b1',1,'mega::MegaApi::disableSync(MegaNode *megaFolder, MegaRequestListener *listener=NULL)'],['../classmega_1_1_mega_api.html#a9c567dbe99d14b4319f8d2ab0e82caea',1,'mega::MegaApi::disableSync(MegaSync *sync, MegaRequestListener *listener=NULL)']]],
  ['disabletransferresumption',['disableTransferResumption',['../classmega_1_1_mega_api.html#ac19fa3d3a28872965676adfa2a43fc7b',1,'mega::MegaApi']]],
  ['doonrequestfinish',['doOnRequestFinish',['../classmega_1_1_synchronous_request_listener.html#ab905a90c6e9c783a1bea570c3713b128',1,'mega::SynchronousRequestListener']]],
  ['doontransferfinish',['doOnTransferFinish',['../classmega_1_1_synchronous_transfer_listener.html#a2009fccd6edd73d0af61ec189b788fcb',1,'mega::SynchronousTransferListener']]],
  ['dumpsession',['dumpSession',['../classmega_1_1_mega_api.html#a529085b6f2448939c32715bad2d968b2',1,'mega::MegaApi']]],
  ['dumpxmppsession',['dumpXMPPSession',['../classmega_1_1_mega_api.html#a56eeae6fcb8b10ab2d76592ed280b03e',1,'mega::MegaApi']]]
];
