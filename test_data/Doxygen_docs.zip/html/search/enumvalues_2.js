var searchData=
[
  ['http_5fserver_5fallow_5fall',['HTTP_SERVER_ALLOW_ALL',['../classmega_1_1_mega_api.html#a2cc81800749a6aa773a180cadc85ffcea4ad1fb2f4c18e3c347f2116d011a4b62',1,'mega::MegaApi']]],
  ['http_5fserver_5fallow_5fcreated_5flocal_5flinks',['HTTP_SERVER_ALLOW_CREATED_LOCAL_LINKS',['../classmega_1_1_mega_api.html#a2cc81800749a6aa773a180cadc85ffcead2acd369e44e6c8de0b03d4f7c3f4c52',1,'mega::MegaApi']]],
  ['http_5fserver_5fallow_5flast_5flocal_5flink',['HTTP_SERVER_ALLOW_LAST_LOCAL_LINK',['../classmega_1_1_mega_api.html#a2cc81800749a6aa773a180cadc85ffcea623f9c7e40ca01eb97c062a4ba0c7769',1,'mega::MegaApi']]],
  ['http_5fserver_5fdeny_5fall',['HTTP_SERVER_DENY_ALL',['../classmega_1_1_mega_api.html#a2cc81800749a6aa773a180cadc85ffcead0bf203a9edcbe7385abc9358b1ffa50',1,'mega::MegaApi']]]
];
