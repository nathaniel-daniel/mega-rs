var searchData=
[
  ['mega_5fdebris_5ffolder',['MEGA_DEBRIS_FOLDER',['../namespacemega.html#a25530a650a79d0ea5b64849813435336',1,'mega']]],
  ['megaapi',['megaApi',['../classmega_1_1_synchronous_request_listener.html#a70b5964e769387d766964f54f9f7561e',1,'mega::SynchronousRequestListener::megaApi()'],['../classmega_1_1_synchronous_transfer_listener.html#ae682271c4689b2f0aadf8e5fff206e45',1,'mega::SynchronousTransferListener::megaApi()']]],
  ['megaerror',['megaError',['../classmega_1_1_synchronous_request_listener.html#ad91d694839af8d57dbb6ee8bcdaa7df1',1,'mega::SynchronousRequestListener::megaError()'],['../classmega_1_1_synchronous_transfer_listener.html#afab54dd2a4cf9a5f2302a4ec2aabac34',1,'mega::SynchronousTransferListener::megaError()']]],
  ['megarequest',['megaRequest',['../classmega_1_1_synchronous_request_listener.html#ac01bd5610cd597c8734d466916c4607f',1,'mega::SynchronousRequestListener']]],
  ['megatransfer',['megaTransfer',['../classmega_1_1_synchronous_transfer_listener.html#a6c13b3c95f624a28f527e9b859dd4485',1,'mega::SynchronousTransferListener']]]
];
