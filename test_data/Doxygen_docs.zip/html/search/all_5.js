var searchData=
[
  ['enabletransferresumption',['enableTransferResumption',['../classmega_1_1_mega_api.html#a8bd059250e55980b98c767033421398c',1,'mega::MegaApi']]],
  ['escapefsincompatible',['escapeFsIncompatible',['../classmega_1_1_mega_api.html#a2c928b85b71fe162167be7115249181e',1,'mega::MegaApi']]],
  ['exportmasterkey',['exportMasterKey',['../classmega_1_1_mega_api.html#a384a29b06775acbcf1f7dab4250d9348',1,'mega::MegaApi']]],
  ['exportnode',['exportNode',['../classmega_1_1_mega_api.html#a98f8352e71bdf22c76b393505a7d5e02',1,'mega::MegaApi::exportNode(MegaNode *node, MegaRequestListener *listener=NULL)'],['../classmega_1_1_mega_api.html#a8f9d380d4793d7fbf6dd29d65ea1af88',1,'mega::MegaApi::exportNode(MegaNode *node, int64_t expireTime, MegaRequestListener *listener=NULL)']]]
];
