var searchData=
[
  ['add',['add',['../classmega_1_1_mega_hash_signature.html#a30d17b1f3f3e278102b61c292c8a5d48',1,'mega::MegaHashSignature']]],
  ['addentropy',['addEntropy',['../classmega_1_1_mega_api.html#a9bd77d8a66ba67e7a5b58f1b544fcacd',1,'mega::MegaApi']]],
  ['addgloballistener',['addGlobalListener',['../classmega_1_1_mega_api.html#a6f4a17852da534bfc1806309d6d7b624',1,'mega::MegaApi']]],
  ['addlistener',['addListener',['../classmega_1_1_mega_api.html#a295359e7ab2839ae18f4b174d3bf8a16',1,'mega::MegaApi']]],
  ['addpeer',['addPeer',['../classmega_1_1_mega_text_chat_peer_list.html#a791bda4b3dba88c7c49d757b2d382876',1,'mega::MegaTextChatPeerList']]],
  ['addrequestlistener',['addRequestListener',['../classmega_1_1_mega_api.html#a5bb3e996258b2f96f5d43df3616f852c',1,'mega::MegaApi']]],
  ['addsynclistener',['addSyncListener',['../classmega_1_1_mega_api.html#af677e97e8d8d961e5fe15e500706f401',1,'mega::MegaApi']]],
  ['addtransferlistener',['addTransferListener',['../classmega_1_1_mega_api.html#ad49bd7c92af194533a280ae55ff42589',1,'mega::MegaApi']]],
  ['aretransferspaused',['areTransfersPaused',['../classmega_1_1_mega_api.html#a594fdaec0f485a8f14a8c60b086ad270',1,'mega::MegaApi']]],
  ['authorizenode',['authorizeNode',['../classmega_1_1_mega_api.html#a246e1ee4267d6fada1eed2e06354e44d',1,'mega::MegaApi']]]
];
