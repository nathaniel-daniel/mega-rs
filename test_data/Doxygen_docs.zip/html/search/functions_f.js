var searchData=
[
  ['pauseactionpackets',['pauseActionPackets',['../classmega_1_1_mega_api.html#a141c7b0659814e3f547f9b440f7a7ed0',1,'mega::MegaApi']]],
  ['pausetransfer',['pauseTransfer',['../classmega_1_1_mega_api.html#af06508f7e03d108e3cdedb29b75f20c0',1,'mega::MegaApi']]],
  ['pausetransferbytag',['pauseTransferByTag',['../classmega_1_1_mega_api.html#ace499d2e2bffaf60f6979b055df66d14',1,'mega::MegaApi']]],
  ['pausetransfers',['pauseTransfers',['../classmega_1_1_mega_api.html#a03792d69540e691f248f513f48093cad',1,'mega::MegaApi::pauseTransfers(bool pause, MegaRequestListener *listener=NULL)'],['../classmega_1_1_mega_api.html#a5cff9a031b86c860b8a270897c6bd1c0',1,'mega::MegaApi::pauseTransfers(bool pause, int direction, MegaRequestListener *listener=NULL)']]],
  ['processmeganode',['processMegaNode',['../classmega_1_1_mega_tree_processor.html#a6ba1281ab4a8090c0f5ad840f7260e3f',1,'mega::MegaTreeProcessor']]],
  ['processmegatree',['processMegaTree',['../classmega_1_1_mega_api.html#a7047376fa2b77a0d4b65657727e33392',1,'mega::MegaApi']]]
];
