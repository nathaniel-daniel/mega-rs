var searchData=
[
  ['visibility_5fblocked',['VISIBILITY_BLOCKED',['../classmega_1_1_mega_user.html#a73a28b2ff6cf893de1426f8347791dafa2e1fe6b71fbd284cc349f5bac8f9dd06',1,'mega::MegaUser']]],
  ['visibility_5fhidden',['VISIBILITY_HIDDEN',['../classmega_1_1_mega_user.html#a73a28b2ff6cf893de1426f8347791dafa55059122ffd4c96b4444a85308be9bbd',1,'mega::MegaUser']]],
  ['visibility_5finactive',['VISIBILITY_INACTIVE',['../classmega_1_1_mega_user.html#a73a28b2ff6cf893de1426f8347791dafae549699b3657349c97653018f33a64d9',1,'mega::MegaUser']]],
  ['visibility_5funknown',['VISIBILITY_UNKNOWN',['../classmega_1_1_mega_user.html#a73a28b2ff6cf893de1426f8347791dafa65934d9d912dffdced7d66a6bbfd978b',1,'mega::MegaUser']]],
  ['visibility_5fvisible',['VISIBILITY_VISIBLE',['../classmega_1_1_mega_user.html#a73a28b2ff6cf893de1426f8347791dafa992c664e785d934bdd6e8955bd114b05',1,'mega::MegaUser']]]
];
