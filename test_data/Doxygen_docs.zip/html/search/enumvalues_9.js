var searchData=
[
  ['reply_5faction_5faccept',['REPLY_ACTION_ACCEPT',['../classmega_1_1_mega_contact_request.html#a2e5250f96a2e52575f7f86857bc219daa6f79022567e09af57b267d45eb77e7ee',1,'mega::MegaContactRequest']]],
  ['reply_5faction_5fdeny',['REPLY_ACTION_DENY',['../classmega_1_1_mega_contact_request.html#a2e5250f96a2e52575f7f86857bc219daa024afe732ec2f5d98a0e403fd9feb138',1,'mega::MegaContactRequest']]],
  ['reply_5faction_5fignore',['REPLY_ACTION_IGNORE',['../classmega_1_1_mega_contact_request.html#a2e5250f96a2e52575f7f86857bc219daa9fee3ad3e959411c5bcfa0555a4090a8',1,'mega::MegaContactRequest']]]
];
