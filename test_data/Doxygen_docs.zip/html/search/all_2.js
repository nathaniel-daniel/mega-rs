var searchData=
[
  ['base32tobase64',['base32ToBase64',['../classmega_1_1_mega_api.html#aff3078caa61dc86ee21ea046091bbae3',1,'mega::MegaApi']]],
  ['base32tohandle',['base32ToHandle',['../classmega_1_1_mega_api.html#aa965d75c8befcd47606762f9a588bdd9',1,'mega::MegaApi']]],
  ['base64tobase32',['base64ToBase32',['../classmega_1_1_mega_api.html#ad2b41490814be976672cfb939c7cdd2b',1,'mega::MegaApi']]],
  ['base64tohandle',['base64ToHandle',['../classmega_1_1_mega_api.html#af40784172f16cc9bdb55835902a8c963',1,'mega::MegaApi']]],
  ['base64touserhandle',['base64ToUserHandle',['../classmega_1_1_mega_api.html#a3af2c42ec0afc3e0a9686373db421ec3',1,'mega::MegaApi']]]
];
