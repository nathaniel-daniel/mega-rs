var searchData=
[
  ['invalid_5fcoordinate',['INVALID_COORDINATE',['../classmega_1_1_mega_node.html#a6b9671e69ff249cfed4e5f1d7f8a3b43',1,'mega::MegaNode']]],
  ['invalid_5fduration',['INVALID_DURATION',['../classmega_1_1_mega_node.html#abdeaebba30bcd5338ccce8216a69c04b',1,'mega::MegaNode']]],
  ['invalid_5fhandle',['INVALID_HANDLE',['../namespacemega.html#a06d1b053d8a1c03f4af40667846f6b48',1,'mega']]]
];
