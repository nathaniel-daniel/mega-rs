var searchData=
[
  ['killsession',['killSession',['../classmega_1_1_mega_api.html#a0c8e1913b6506c337e9668d7b5c62ee6',1,'mega::MegaApi']]]
];
