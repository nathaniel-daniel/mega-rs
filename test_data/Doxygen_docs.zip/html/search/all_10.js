var searchData=
[
  ['querycancellink',['queryCancelLink',['../classmega_1_1_mega_api.html#ac87efa8c0da9b6dd6aba0f58de983fcb',1,'mega::MegaApi']]],
  ['querychangeemaillink',['queryChangeEmailLink',['../classmega_1_1_mega_api.html#a3bb01b8d1ce7be7f99fd48431c1275d9',1,'mega::MegaApi']]],
  ['queryresetpasswordlink',['queryResetPasswordLink',['../classmega_1_1_mega_api.html#ac90a577251510ec74373afb4bace5e74',1,'mega::MegaApi']]],
  ['querysignuplink',['querySignupLink',['../classmega_1_1_mega_api.html#ad15d93037ffa2cb4fd1138717ab9fb36',1,'mega::MegaApi']]]
];
