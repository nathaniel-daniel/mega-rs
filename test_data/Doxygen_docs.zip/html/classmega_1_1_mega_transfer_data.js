var classmega_1_1_mega_transfer_data =
[
    [ "~MegaTransferData", "classmega_1_1_mega_transfer_data.html#aebb58a5199a2995fe347d04de133db67", null ],
    [ "copy", "classmega_1_1_mega_transfer_data.html#a45e5ef5a712d9a70f29bd56b3aa6a058", null ],
    [ "getDownloadPriority", "classmega_1_1_mega_transfer_data.html#ae37d48ff045dbf5b327e502f03b88fd3", null ],
    [ "getDownloadTag", "classmega_1_1_mega_transfer_data.html#a691a40099f88d12ceb26f461026ac2d3", null ],
    [ "getNumDownloads", "classmega_1_1_mega_transfer_data.html#aa1f210c668298eec292a3755be5fbb3d", null ],
    [ "getNumUploads", "classmega_1_1_mega_transfer_data.html#af2400121fde74dc7fdcb8aacc5ab4323", null ],
    [ "getUploadPriority", "classmega_1_1_mega_transfer_data.html#ac9b39e1e75432f61bfc663082fa278ea", null ],
    [ "getUploadTag", "classmega_1_1_mega_transfer_data.html#aa6339388d90ac264e7232455a81e16a8", null ]
];