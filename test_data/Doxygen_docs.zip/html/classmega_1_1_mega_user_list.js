var classmega_1_1_mega_user_list =
[
    [ "~MegaUserList", "classmega_1_1_mega_user_list.html#a0e0db24e25f2c37e3cd5d3b209b815b8", null ],
    [ "copy", "classmega_1_1_mega_user_list.html#ad04528698656bbe092bc9d46b6b4510d", null ],
    [ "get", "classmega_1_1_mega_user_list.html#a9ebf2124267f7b94e4f88ef37164961c", null ],
    [ "size", "classmega_1_1_mega_user_list.html#ab98dcc6d355bd52e4071607bbd6e9da0", null ]
];