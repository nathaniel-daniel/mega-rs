var classmega_1_1_mega_sync =
[
    [ "SYNC_FAILED", "classmega_1_1_mega_sync.html#abbaa3b87e27f36d73569a8921ac4bb1ca7362e8bf99da1e66ee4bc775aa73d31e", null ],
    [ "SYNC_CANCELED", "classmega_1_1_mega_sync.html#abbaa3b87e27f36d73569a8921ac4bb1ca865e30c1b6ee258d6e1b1f5b71ed9ecb", null ],
    [ "SYNC_INITIALSCAN", "classmega_1_1_mega_sync.html#abbaa3b87e27f36d73569a8921ac4bb1ca4c8c2d99852b0451c8dc5ee1e1465e31", null ],
    [ "SYNC_ACTIVE", "classmega_1_1_mega_sync.html#abbaa3b87e27f36d73569a8921ac4bb1ca47f15960693e92d4c0f8326281960f0e", null ],
    [ "~MegaSync", "classmega_1_1_mega_sync.html#a89ff449a8738f5d8d9208bd01ebd4f10", null ],
    [ "copy", "classmega_1_1_mega_sync.html#a171852315a59ca493ef55c35bd81c847", null ],
    [ "getLocalFingerprint", "classmega_1_1_mega_sync.html#aca6b65c43423ee225d458fb84aefbfbf", null ],
    [ "getLocalFolder", "classmega_1_1_mega_sync.html#a27444432f80ea092200edfde83359b39", null ],
    [ "getMegaHandle", "classmega_1_1_mega_sync.html#acc97c8f8f9291fcef8c99f680dd5ab8e", null ],
    [ "getState", "classmega_1_1_mega_sync.html#a650936c224c98417e2fd5813ade952dd", null ],
    [ "getTag", "classmega_1_1_mega_sync.html#ab855bbf3049f4a62ec2cc11c40e78b7f", null ]
];