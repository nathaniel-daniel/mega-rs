var classmega_1_1_mega_sync_listener =
[
    [ "onSyncEvent", "classmega_1_1_mega_sync_listener.html#aa3414509bd94fe6477591e8465f81895", null ],
    [ "onSyncFileStateChanged", "classmega_1_1_mega_sync_listener.html#a67448a387dfcab58055413c52bb0797e", null ],
    [ "onSyncStateChanged", "classmega_1_1_mega_sync_listener.html#a9ddb4d492f4caa3ce73e3b11a22e412e", null ]
];