var classmega_1_1_mega_logger =
[
    [ "~MegaLogger", "classmega_1_1_mega_logger.html#ab8b1d539ec1fcf33f5103fddee96f03e", null ],
    [ "log", "classmega_1_1_mega_logger.html#a710fb8f3bf6e107c1c0455587b1af8aa", null ]
];