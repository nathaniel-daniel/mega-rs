var classmega_1_1_mega_share =
[
    [ "ACCESS_UNKNOWN", "classmega_1_1_mega_share.html#a4d64776c9bfce2a93f32e3d469e0caf3aac6158eb429cd612ec73d5c32e568677", null ],
    [ "ACCESS_READ", "classmega_1_1_mega_share.html#a4d64776c9bfce2a93f32e3d469e0caf3a2b4d3257345f0ae00280a0f03f0d7b62", null ],
    [ "ACCESS_READWRITE", "classmega_1_1_mega_share.html#a4d64776c9bfce2a93f32e3d469e0caf3af5c80406deeb323fc68a9598b198098a", null ],
    [ "ACCESS_FULL", "classmega_1_1_mega_share.html#a4d64776c9bfce2a93f32e3d469e0caf3a8b78892e7904208226699a7ccee6b704", null ],
    [ "ACCESS_OWNER", "classmega_1_1_mega_share.html#a4d64776c9bfce2a93f32e3d469e0caf3aba8c72295668b9af76d801560d23bc24", null ],
    [ "~MegaShare", "classmega_1_1_mega_share.html#a1645c953a8a3596a8e0e0c2c37e23cf7", null ],
    [ "copy", "classmega_1_1_mega_share.html#a8831fa5a9561f1accb796739fee44dc2", null ],
    [ "getAccess", "classmega_1_1_mega_share.html#afd612466d29f4942d2e1874991318dbc", null ],
    [ "getNodeHandle", "classmega_1_1_mega_share.html#a31d6f8b69d897d45a66a8eae2e7c18b1", null ],
    [ "getTimestamp", "classmega_1_1_mega_share.html#a73bccafdff8ab095af5d5cd6b83932cd", null ],
    [ "getUser", "classmega_1_1_mega_share.html#a58a25afeae8e72b5efbf2e6f7f6d1d6d", null ]
];