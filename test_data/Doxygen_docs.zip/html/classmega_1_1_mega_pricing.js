var classmega_1_1_mega_pricing =
[
    [ "~MegaPricing", "classmega_1_1_mega_pricing.html#af43e9bd70840da71146e0addeeeb9dfe", null ],
    [ "copy", "classmega_1_1_mega_pricing.html#ab4fd7974338e6ad52d970f6d77fd3d12", null ],
    [ "getAmount", "classmega_1_1_mega_pricing.html#ad31cb3b8bb4d7409dfb34e9b5bce55cc", null ],
    [ "getAndroidID", "classmega_1_1_mega_pricing.html#afb531af4fb182ee6cf9136196be3df71", null ],
    [ "getCurrency", "classmega_1_1_mega_pricing.html#aa2324cc888f60afe377718eef9305054", null ],
    [ "getDescription", "classmega_1_1_mega_pricing.html#a8d0ab3fe6fec387c5b4d57426fccfac3", null ],
    [ "getGBStorage", "classmega_1_1_mega_pricing.html#a51f95d6d5dfeb2c0f65f3569f38f89ab", null ],
    [ "getGBTransfer", "classmega_1_1_mega_pricing.html#a9d0484ed549a3832540b9d75067dfb70", null ],
    [ "getHandle", "classmega_1_1_mega_pricing.html#a6d2cb2f1a3805c92666eac73d3066038", null ],
    [ "getIosID", "classmega_1_1_mega_pricing.html#a558dbeed69c5d86c9a72c39ee56cf90c", null ],
    [ "getMonths", "classmega_1_1_mega_pricing.html#a912bf79155fb007355aac30d47cf6e05", null ],
    [ "getNumProducts", "classmega_1_1_mega_pricing.html#ad58cc7898928901db1300c9880dedb0b", null ],
    [ "getProLevel", "classmega_1_1_mega_pricing.html#a3ae709e3497347709bc1cb20bd3f6f21", null ]
];