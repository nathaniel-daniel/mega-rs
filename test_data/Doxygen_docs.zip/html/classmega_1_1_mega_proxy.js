var classmega_1_1_mega_proxy =
[
    [ "PROXY_NONE", "classmega_1_1_mega_proxy.html#a0ba787fcd5a05cb7ad4b81fb5be44d0aabba085ac4493c63d223c719f0961f68c", null ],
    [ "PROXY_AUTO", "classmega_1_1_mega_proxy.html#a0ba787fcd5a05cb7ad4b81fb5be44d0aa310d05c5552ef76fac29662f37a09adf", null ],
    [ "PROXY_CUSTOM", "classmega_1_1_mega_proxy.html#a0ba787fcd5a05cb7ad4b81fb5be44d0aa289278a3a3b493ff4602427d522a988e", null ],
    [ "MegaProxy", "classmega_1_1_mega_proxy.html#aace50c748cdbf154f35753435bbf1776", null ],
    [ "~MegaProxy", "classmega_1_1_mega_proxy.html#a34721798c310eab250a093e915325f37", null ],
    [ "credentialsNeeded", "classmega_1_1_mega_proxy.html#a57eba6b58adece73253a9c92a68aca68", null ],
    [ "getPassword", "classmega_1_1_mega_proxy.html#a9836768b66c3cf7fa0eedfc93b97db64", null ],
    [ "getProxyType", "classmega_1_1_mega_proxy.html#a67e29d15ebbfcca0cc5602402b5cca75", null ],
    [ "getProxyURL", "classmega_1_1_mega_proxy.html#a617243f8d23133d1edafb9dcc854d824", null ],
    [ "getUsername", "classmega_1_1_mega_proxy.html#ad8bb322afc8f78af51ebc8248788dd3f", null ],
    [ "setCredentials", "classmega_1_1_mega_proxy.html#a16d3b46e641ef0c088d109ad86ae1cbc", null ],
    [ "setProxyType", "classmega_1_1_mega_proxy.html#a14c3357078ebfac41c73cd35b867cb63", null ],
    [ "setProxyURL", "classmega_1_1_mega_proxy.html#aee2e3077326dcb6d9b757c8fcad79792", null ]
];