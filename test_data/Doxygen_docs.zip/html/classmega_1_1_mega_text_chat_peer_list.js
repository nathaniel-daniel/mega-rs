var classmega_1_1_mega_text_chat_peer_list =
[
    [ "PRIV_UNKNOWN", "classmega_1_1_mega_text_chat_peer_list.html#a144f782a7f5ff0f5abb6d847744a9c35a82ff7f83a6a203a2017a8ea1e450fb39", null ],
    [ "PRIV_RM", "classmega_1_1_mega_text_chat_peer_list.html#a144f782a7f5ff0f5abb6d847744a9c35a4e893045a7acd288c7b7a6d0ac14ade7", null ],
    [ "PRIV_RO", "classmega_1_1_mega_text_chat_peer_list.html#a144f782a7f5ff0f5abb6d847744a9c35ac58cb153768d206896bef7967c158107", null ],
    [ "PRIV_STANDARD", "classmega_1_1_mega_text_chat_peer_list.html#a144f782a7f5ff0f5abb6d847744a9c35a540651f34988e0d0e03d1b923addb869", null ],
    [ "PRIV_MODERATOR", "classmega_1_1_mega_text_chat_peer_list.html#a144f782a7f5ff0f5abb6d847744a9c35a77e8cd573ea2a1890070ae8180859464", null ],
    [ "~MegaTextChatPeerList", "classmega_1_1_mega_text_chat_peer_list.html#a75a057538fbdcc02cbfe0617f7c0e26d", null ],
    [ "MegaTextChatPeerList", "classmega_1_1_mega_text_chat_peer_list.html#a544213e8e808148a4ce17f89c1e5f193", null ],
    [ "addPeer", "classmega_1_1_mega_text_chat_peer_list.html#a791bda4b3dba88c7c49d757b2d382876", null ],
    [ "copy", "classmega_1_1_mega_text_chat_peer_list.html#a9622a4297373bf3a8b7ab02c199c4b53", null ],
    [ "createInstance", "classmega_1_1_mega_text_chat_peer_list.html#a87dee9f1784097bee470003cd30ec698", null ],
    [ "getPeerHandle", "classmega_1_1_mega_text_chat_peer_list.html#a0476ffc58c4a1219d6629b46b5cdb451", null ],
    [ "getPeerPrivilege", "classmega_1_1_mega_text_chat_peer_list.html#ae9ea154dedddeeefc0a037540a044dbc", null ],
    [ "size", "classmega_1_1_mega_text_chat_peer_list.html#a38b78374ca1a6d73619adfb75711792f", null ]
];