var classmega_1_1_mega_text_chat =
[
    [ "~MegaTextChat", "classmega_1_1_mega_text_chat.html#a6bebda6e88400fc075ff9c8ca8e49ac0", null ],
    [ "copy", "classmega_1_1_mega_text_chat.html#a2b5931bf83f12f853ca0d836ce1045e8", null ],
    [ "getHandle", "classmega_1_1_mega_text_chat.html#ac50dd749f31442f98d57c84f75316513", null ],
    [ "getOriginatingUser", "classmega_1_1_mega_text_chat.html#a3c390c85a6aca21375820897dd04b575", null ],
    [ "getOwnPrivilege", "classmega_1_1_mega_text_chat.html#a2427ad4b112be13a5b2270069cb5541f", null ],
    [ "getPeerList", "classmega_1_1_mega_text_chat.html#aec3d4cbddde1503cf1eb2c1283f86094", null ],
    [ "getShard", "classmega_1_1_mega_text_chat.html#a25153d741e2df69ebcef6f1f77051ddb", null ],
    [ "getTitle", "classmega_1_1_mega_text_chat.html#af4dde9bca15997ac7dc9063674b2c7a6", null ],
    [ "getUrl", "classmega_1_1_mega_text_chat.html#a0bc5c46fcbded3a05855f1e7e7c4f86f", null ],
    [ "isGroup", "classmega_1_1_mega_text_chat.html#afe2e0069be38048669e85b97d1a4b1c0", null ],
    [ "setUrl", "classmega_1_1_mega_text_chat.html#a67077429e2c84e4a1d43689865d81ca1", null ]
];