var classmega_1_1_mega_input_stream =
[
    [ "~MegaInputStream", "classmega_1_1_mega_input_stream.html#a7a1d991d2197219bc8dfc231d944f102", null ],
    [ "getSize", "classmega_1_1_mega_input_stream.html#a4924e09ec6262ebc54bf14eb1d40e0b9", null ],
    [ "read", "classmega_1_1_mega_input_stream.html#a8e6300c94d74499c53c6d530494763d9", null ]
];