var classmega_1_1_mega_account_session =
[
    [ "~MegaAccountSession", "classmega_1_1_mega_account_session.html#a52894eb44f7be276f43c909027136331", null ],
    [ "getCountry", "classmega_1_1_mega_account_session.html#a811dd2b0914111e29c283e352e21d700", null ],
    [ "getCreationTimestamp", "classmega_1_1_mega_account_session.html#a99e89b0564e3476382ea01c8ebe07a86", null ],
    [ "getHandle", "classmega_1_1_mega_account_session.html#a138eae396b15b93b8985f940dc4e3d30", null ],
    [ "getIP", "classmega_1_1_mega_account_session.html#a4035d6659f1bc49110d16d0641c9463f", null ],
    [ "getMostRecentUsage", "classmega_1_1_mega_account_session.html#a9d8ebdd93f339eac4826046c77ad2a15", null ],
    [ "getUserAgent", "classmega_1_1_mega_account_session.html#adcaba40a2359df9361bf3c1553bf7acb", null ],
    [ "isAlive", "classmega_1_1_mega_account_session.html#aac3754ac39648d0f85afe4663cf1040e", null ],
    [ "isCurrent", "classmega_1_1_mega_account_session.html#a4f49a418b437066b56d2159cefc78308", null ]
];