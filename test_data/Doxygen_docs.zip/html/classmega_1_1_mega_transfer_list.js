var classmega_1_1_mega_transfer_list =
[
    [ "~MegaTransferList", "classmega_1_1_mega_transfer_list.html#a22f4dd28cd7ff38971401d1c6866a180", null ],
    [ "get", "classmega_1_1_mega_transfer_list.html#a20ca82ed398b5a0b539df34b7748e8c4", null ],
    [ "size", "classmega_1_1_mega_transfer_list.html#ac496605b283c88e0649f8afc2c6ea5a6", null ]
];