var classmega_1_1_mega_account_transaction =
[
    [ "~MegaAccountTransaction", "classmega_1_1_mega_account_transaction.html#ae2b297891409aff5a516f859c27026e7", null ],
    [ "getAmount", "classmega_1_1_mega_account_transaction.html#a2732c564eeae85634cbe186c2abd1944", null ],
    [ "getCurrency", "classmega_1_1_mega_account_transaction.html#ab1942b5f41abacd12fe04be3c6d2dda1", null ],
    [ "getHandle", "classmega_1_1_mega_account_transaction.html#a66e41d2f83fdc5b2283842c79c9d0148", null ],
    [ "getTimestamp", "classmega_1_1_mega_account_transaction.html#a643bc124f3d1baef1f3f5442f70ada0c", null ]
];