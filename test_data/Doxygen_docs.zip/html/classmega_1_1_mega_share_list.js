var classmega_1_1_mega_share_list =
[
    [ "~MegaShareList", "classmega_1_1_mega_share_list.html#a903064237a9df196fa5ad2d27f0c53cd", null ],
    [ "get", "classmega_1_1_mega_share_list.html#a834625ac9c470334c00e183211430496", null ],
    [ "size", "classmega_1_1_mega_share_list.html#a39f5b904565388e6e1bad9bf1950dd7f", null ]
];