var classmega_1_1_mega_string_list =
[
    [ "~MegaStringList", "classmega_1_1_mega_string_list.html#a4361fb9417dbe6277cc6a6dbbe92d6d3", null ],
    [ "copy", "classmega_1_1_mega_string_list.html#a6f8dbc207b61762084f8464533235372", null ],
    [ "get", "classmega_1_1_mega_string_list.html#a5def845bacb021cef272ae852b30e5f2", null ],
    [ "size", "classmega_1_1_mega_string_list.html#a4d3fdd7911e55c7ac64e43c43bc0ad53", null ]
];