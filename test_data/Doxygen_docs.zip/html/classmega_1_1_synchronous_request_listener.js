var classmega_1_1_synchronous_request_listener =
[
    [ "SynchronousRequestListener", "classmega_1_1_synchronous_request_listener.html#a5479c55de58332464fb060bf207a8eec", null ],
    [ "~SynchronousRequestListener", "classmega_1_1_synchronous_request_listener.html#a202b3963553c27c69dd4c69cfc1c2453", null ],
    [ "doOnRequestFinish", "classmega_1_1_synchronous_request_listener.html#ab905a90c6e9c783a1bea570c3713b128", null ],
    [ "getApi", "classmega_1_1_synchronous_request_listener.html#a19469e9737e03fefc18d81ab9c5554a6", null ],
    [ "getError", "classmega_1_1_synchronous_request_listener.html#a1b4c407d9a4b1d0524a04e6c0c7cbdcb", null ],
    [ "getRequest", "classmega_1_1_synchronous_request_listener.html#a64cd489ef429acabd362eaa3c44a39b5", null ],
    [ "trywait", "classmega_1_1_synchronous_request_listener.html#ac750b332faa74f048bcc51e1324555f3", null ],
    [ "wait", "classmega_1_1_synchronous_request_listener.html#a6c61f495bb3138baa6f53fc272c12365", null ],
    [ "listener", "classmega_1_1_synchronous_request_listener.html#a02cf865bc5fcb70e7ea89cb548874877", null ],
    [ "megaApi", "classmega_1_1_synchronous_request_listener.html#a70b5964e769387d766964f54f9f7561e", null ],
    [ "megaError", "classmega_1_1_synchronous_request_listener.html#ad91d694839af8d57dbb6ee8bcdaa7df1", null ],
    [ "megaRequest", "classmega_1_1_synchronous_request_listener.html#ac01bd5610cd597c8734d466916c4607f", null ]
];