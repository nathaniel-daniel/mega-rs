var classmega_1_1_mega_listener =
[
    [ "~MegaListener", "classmega_1_1_mega_listener.html#a4e4cecdcf6a0f802c1e686a60b13616e", null ],
    [ "onAccountUpdate", "classmega_1_1_mega_listener.html#af3627a0ccc5bfbfa5c5b87bccac9723e", null ],
    [ "onChatsUpdate", "classmega_1_1_mega_listener.html#a33ce48ce286ad83f613590c2be6da39a", null ],
    [ "onContactRequestsUpdate", "classmega_1_1_mega_listener.html#a1a9ae400d1a3aa5f5254ee28ec3aa440", null ],
    [ "onGlobalSyncStateChanged", "classmega_1_1_mega_listener.html#a1b3339cdb778ab17585a902a9679269d", null ],
    [ "onNodesUpdate", "classmega_1_1_mega_listener.html#a07b44a62f7b1a983e39b73e72721b699", null ],
    [ "onReloadNeeded", "classmega_1_1_mega_listener.html#ac2f18a4436d7a7e66b4861e3446fd47a", null ],
    [ "onRequestFinish", "classmega_1_1_mega_listener.html#a0e13b2324cc0d01e41c08909d21ea426", null ],
    [ "onRequestStart", "classmega_1_1_mega_listener.html#a5337c789aa7bf11ca679b946fa2fadd6", null ],
    [ "onRequestTemporaryError", "classmega_1_1_mega_listener.html#a875e3c88d1a8c512b7ac465eccb9496e", null ],
    [ "onRequestUpdate", "classmega_1_1_mega_listener.html#a7d33f8577bee5bdf6e80bf056bd454fe", null ],
    [ "onSyncEvent", "classmega_1_1_mega_listener.html#a5d9f1ce12c8ac81709f1c93bf062f90d", null ],
    [ "onSyncFileStateChanged", "classmega_1_1_mega_listener.html#ac606afa29f554663bc3d5cab48bec01f", null ],
    [ "onSyncStateChanged", "classmega_1_1_mega_listener.html#a914e069bad59ae76dea61ffae6ebb43a", null ],
    [ "onTransferFinish", "classmega_1_1_mega_listener.html#a48576abd2780704829336c7a68b0d0ff", null ],
    [ "onTransferStart", "classmega_1_1_mega_listener.html#a96ae97bf23e1a0d91e296450ba51e8a7", null ],
    [ "onTransferTemporaryError", "classmega_1_1_mega_listener.html#ac3b5c9570cc79016bf6aa7ea58b1b2b3", null ],
    [ "onTransferUpdate", "classmega_1_1_mega_listener.html#a61dbf3f7ea2aae2769571690ef053b1b", null ],
    [ "onUsersUpdate", "classmega_1_1_mega_listener.html#a43a12390fc8a65c9720597412c791347", null ]
];