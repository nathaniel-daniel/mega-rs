var classmega_1_1_mega_account_balance =
[
    [ "~MegaAccountBalance", "classmega_1_1_mega_account_balance.html#a89e5d35813b1c7808ff847718a6e6806", null ],
    [ "getAmount", "classmega_1_1_mega_account_balance.html#a4bf6634397c01aa8aa002dd654718f79", null ],
    [ "getCurrency", "classmega_1_1_mega_account_balance.html#a4287eead79e338587e9701dd1b6612c2", null ]
];