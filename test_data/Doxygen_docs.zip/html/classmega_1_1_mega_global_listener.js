var classmega_1_1_mega_global_listener =
[
    [ "~MegaGlobalListener", "classmega_1_1_mega_global_listener.html#aa444c3db1d013db908239bc318c13681", null ],
    [ "onAccountUpdate", "classmega_1_1_mega_global_listener.html#a1cc5e1ff134372ba1269155ff86cc90a", null ],
    [ "onChatsUpdate", "classmega_1_1_mega_global_listener.html#aafcd3884919df68740b0bb21f99904e2", null ],
    [ "onContactRequestsUpdate", "classmega_1_1_mega_global_listener.html#a552bb0d49dd113690752eab04e681f67", null ],
    [ "onGlobalSyncStateChanged", "classmega_1_1_mega_global_listener.html#afdce99cf827669a1ea232cfba45495c0", null ],
    [ "onNodesUpdate", "classmega_1_1_mega_global_listener.html#af201e0384ae10bd1e1bdaefcddb6eb22", null ],
    [ "onReloadNeeded", "classmega_1_1_mega_global_listener.html#af5c7b91f008b4fa654ae6b33446ced5e", null ],
    [ "onUsersUpdate", "classmega_1_1_mega_global_listener.html#ac2080a5a9e6859c27954d6b01f68ae54", null ]
];