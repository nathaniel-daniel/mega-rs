var classmega_1_1_mega_account_purchase =
[
    [ "~MegaAccountPurchase", "classmega_1_1_mega_account_purchase.html#af3d10e3b4e389d18dfb1811be372f20f", null ],
    [ "getAmount", "classmega_1_1_mega_account_purchase.html#a401726016083fa45ce23f1a7811d4235", null ],
    [ "getCurrency", "classmega_1_1_mega_account_purchase.html#a16964483f05da18260602a3e95577e1f", null ],
    [ "getHandle", "classmega_1_1_mega_account_purchase.html#a285f3de5f01c286334084c9351a6ed79", null ],
    [ "getMethod", "classmega_1_1_mega_account_purchase.html#a0a9c7052e15ae776a8761195ceabe4b9", null ],
    [ "getTimestamp", "classmega_1_1_mega_account_purchase.html#a7db6d94b4dcd3df296df260de483f73f", null ]
];